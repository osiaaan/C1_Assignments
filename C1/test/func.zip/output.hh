#ifndef OUTPUT_H
#define OUTPUT_H

#include <vector>
#include <string>

void outputVector(std::vector<double> v, std::string filename);

#endif
